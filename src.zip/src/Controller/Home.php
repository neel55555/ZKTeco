<?php

namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\Controller;
use Symfony\Component\HttpFoundation\Response;
use Symfony\Component\HttpFoundation\JsonResponse;
use Sensio\Bundle\FrameworkExtraBundle\Configuration\Method;
use Symfony\Component\Routing\Annotation\Route;
//use TADPHP\TADFactory;
//use TADPHP\TAD;
//use App\Zk\ZKLibrary;

use App\Entity\UserInfo;


class Home extends Controller
{
    /**
     *@Route("/user-log", name="homePage")
     *@Method("GET")
     */
    public function userLog()
    {
        $em = $this->getDoctrine()->getManager();
        
        //$user = $em->getRepository('App\Entity\UserInfo')->findOneBy(['USERID'=>70]);
        //$data = $this->container->get('jms_serializer')->serialize($user->getLogs(), 'json');

        $user = $em->getRepository('App\Entity\UserInfo')->findAll();
        $data = $this->container->get('jms_serializer')->serialize($user, 'json');
        $response =  new Response($data);
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @Route("/users", name="users")
     * @Method("GET")
     */
    public function users()
    {
        $em = $this->getDoctrine()->getManager();
        //$userRepo = $em->getRepository(UserInfo::Class);
        $qb = $em->createQueryBuilder();
        $query = $qb->select('u.Name', 'u.Badgenumber')->from(UserInfo::Class, 'u')->orderBy('u.Badgenumber', 'ASC')->getQuery();
        $data = $query->getResult();
        
        //$data = $em->getRepository(UserInfo::class)->findAll();
        $data = $this->container->get('jms_serializer')->serialize($data, 'json');
        $response = new Response($data);
        $response->headers->set('Content-Type', 'application/json');
        return $response;
    }

    /**
     * @Method("GET")
     * @Route("/tad", name="tad")
     */
    public function tad()
    {
        //$comands = TAD::commands_available();
        //$tad = (new TADFactory(['ip'=>'192.168.1.205', 'com_key'=>0, 'soap_port' => 4370]))->get_instance();
        //$dt = $tad->get_date();
        //return new Response($dt);
        $zk = new ZKLibrary('192.168.1.205', 4370);
        $zk->connect();
        return new Response($zk->getOSVersion($net = true));
    }

    /**
     * @Route("/tcp")
     */
    public function tcp()
    {
        echo "Contacting Machine...\n";

        $Connect = fsockopen("192.168.1.205", 4370, $errno, $errstr, 1);
        if($Connect) {
            echo 'Machine Connected...';
            $soap_request='<?xml version="1.0" standalone="no"?>
            <SOAP-ENV:Envelope xmlns:SOAP-ENV="http://schemas.xmlsoap.org/soap/envelope/">
                <SOAP-ENV:Body>
                    <GetAllUserInfo>
                    <ArgComKey xsi:type="xsd:integer">
                    </ArgComKey>
                    </GetAllUserInfo>
                </SOAP-ENV:Body>
            </SOAP-ENV:Envelope>';
            $newLine="\r\n";
            fputs($Connect, "POST /iWsService HTTP/1.0".$newLine);
            fputs($Connect, "Content-Type: text/xml".$newLine);
            fputs($Connect, "Content-Length: ".strlen($soap_request).$newLine.$newLine);
            fputs($Connect, $soap_request.$newLine);
            $buffer = fgets($Connect, 1024);
            
        } else die("FAILED");

        dump($buffer);
        return new Response('');
    }
}