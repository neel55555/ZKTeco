<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;

/**
 * @ORM\Entity()
 * @ORM\Table(name="USERINFO")
 */
class UserInfo
{
    public function __construct()
    {
        $this->logs = new ArrayCollection();
    }

    /**
     * @ORM\GeneratedValue(strategy="AUTO")
     * @ORM\Column(name="USERID", type="integer")
     */
    private $USERID;

    /**
     * @ORM\Id()
     * @ORM\Column(name="Badgenumber", type="integer")
     */
    private $Badgenumber;

    /**
     * @ORM\Column(type="string");
     */
    private $Name;

    /**
     * @ORM\OneToMany(targetEntity="AccMonitorLog", mappedBy="pin")
     */
    private $logs;

    public function getId()
    {
        return $this->USERID;
    }

    public function getName()
    {
        return $this->Name;
    }

    public function getLogs()
    {
        return $this->logs;
    }

}