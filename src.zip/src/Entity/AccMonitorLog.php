<?php

namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

/**
 * @ORM\Entity(repositoryClass="")
 * @ORM\Table(name="acc_monitor_log")
 */
class AccMonitorLog
{
    /**
     * @ORM\Id()
     * @ORM\Column(type="integer")
     */
    private $id;

    /**
     * @ORM\Column(type="datetime")
     */
    private $time;

    /**
     * @ORM\ManyToOne(targetEntity="UserInfo", inversedBy="logs")
     * @ORM\JoinColumn(name="pin", referencedColumnName="Badgenumber")
     */
    private $pin;

    public function getTime()
    {
        return $this->time;
    }

    public function getPin()
    {
        return $this->pin;
    }
}